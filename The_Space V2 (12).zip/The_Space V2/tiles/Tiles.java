import java.awt.image.BufferedImage;

public class Tiles {
  public BufferedImage image;
  public boolean collision = false;
} // end of class Tiles
