
public class TileManager {
  
  public Tiles[] t;
} // end of class TileManager
