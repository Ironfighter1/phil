import java.io.File;
import java.util.Random;
import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Bounds;
import javafx.geometry.Insets;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.*;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.paint.Color;
import javafx.scene.Scene;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;

public class HackminigameA extends Application {
  // Anfang Attribute
  public boolean cable1Connected = false;
  private boolean cable2Connected = false;
  public boolean geschafft = false;
  ImageView cable1 = new ImageView(new Image("kabel1.png"));
  ImageView cable2 = new ImageView(new Image("kabel2.png"));
  Stage primaryStage;
  private double initialX1, initialY1;
  private double initialX2, initialY2;
  boolean systemoutprint = false;
  private The_Space game;
  The_Space g = new The_Space();
  private String door = "Door.mp3";
  
  // Ende Attribute
  public void start(Stage primaryStage) {
    Pane root = new Pane();
    this.primaryStage = primaryStage;
    Image backgroundImage = new Image("Minigame1.png");
    ImageView background = new ImageView(backgroundImage);
    background.setFitWidth(800);
    background.setFitHeight(800);
    root.getChildren().add(background);
    
    cable1.setLayoutX(50);
    cable1.setLayoutY(230);
    root.getChildren().add(cable1);
    
    cable2.setLayoutX(400);
    cable2.setLayoutY(70);
    root.getChildren().add(cable2);
                                             
    cable1.setOnDragDetected(event -> {
      if (!cable2Connected) { // Erlaube das Ziehen nur, wenn Kabel 2 nicht angeschlossen ist
        Dragboard db = cable1.startDragAndDrop(TransferMode.ANY);
        ClipboardContent content = new ClipboardContent();
        content.putImage(cable1.getImage());
        db.setContent(content);
        event.consume();
      }
    });
    
    cable2.setOnDragOver(event -> {
      if (!cable1Connected && event.getGestureSource() == cable1 && event.getDragboard().hasImage()) {
        event.acceptTransferModes(TransferMode.ANY);
      }
      event.consume();
    });
    
    cable2.setOnDragDropped(event -> {
      if (!cable1Connected && event.getGestureSource() == cable1 && event.getDragboard().hasImage()) {
        cable1.setLayoutX(cable2.getLayoutX() + 20); // Kabel 1 näher an Kabel 2 platzieren
        cable1.setLayoutY(cable2.getLayoutY() + 20); // Kabel 1 näher an Kabel 2 platzieren
        cable1Connected = true;
        handleGameCompleted(cable1Connected);
        
      }
      event.setDropCompleted(true);
      event.consume();
    });
    
    
    Scene scene = new Scene(root, 800, 800);
    // Anfang Komponenten
    // Ende Komponenten
    primaryStage.setScene(scene);
    primaryStage.show();
    
  }
  

  // Anfang Methoden
 public boolean handleGameCompleted(boolean cable1Connected) {
    if (cable1Connected) {
        geschafft = true; 
       
    }
    
    if (geschafft) {
        System.out.println("Geschafft");
        systemoutprint = true; 
      
          g.geöffnet = true;
      
        // Erstellen Sie ein File-Objekt mit dem relativen Pfad
            File file = new File(door);
            // Konvertieren Sie das File-Objekt in eine URI
            String uriString = file.toURI().toString();
            // Erstellen Sie die Media mit der URI
            Media sound = new Media(uriString);
            MediaPlayer mediaPlayer = new MediaPlayer(sound);
            // Setzen Sie die Lautstärke auf 0.5 (50% Lautstärke)
            mediaPlayer.setVolume(1000);
            // Event Listener, um den MediaPlayer nach dem Abspielen freizugeben
            mediaPlayer.setOnEndOfMedia(() -> mediaPlayer.dispose());
            // Abspielen des Sounds
            mediaPlayer.play();     
            primaryStage.close(); 
       
    }

    if (systemoutprint) {
        System.out.println("ist true");  
    }

    geschafft = true;
    return geschafft;
}
  
  public static void main(String[] args) {
    launch(args);
  }
  
  

  // Ende Methoden
}