import javafx.scene.Node;

public class Camera {
    private double offsetX;
    private double offsetY;
    private double minX;
    private double minY;
    private double maxX;
    private double maxY;

    public Camera(double offsetX, double offsetY, double minX, double minY, double maxX, double maxY) {
        this.offsetX = offsetX;
        this.offsetY = offsetY;
        this.minX = minX;
        this.minY = minY;
        this.maxX = maxX;
        this.maxY = maxY;
    }

    public void centerOn(Node target, double sceneWidth, double sceneHeight) {
        double targetX = target.getBoundsInParent().getMinX() + target.getBoundsInParent().getWidth();
        double targetY = target.getBoundsInParent().getMinY() + target.getBoundsInParent().getHeight();

        offsetX = clamp(targetX - sceneWidth / 2, minX, maxX - sceneWidth);
        offsetY = clamp(targetY - sceneHeight / 2, minY, maxY - sceneHeight);
    }

    public double getOffsetX() {
        return offsetX;
    }

    public double getOffsetY() {
        return offsetY;
    }

    private double clamp(double value, double min, double max) {
        return Math.min(Math.max(value, min), max);
    }
}