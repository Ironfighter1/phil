import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import javafx.animation.Animation.Status;
import javafx.animation.AnimationTimer;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.animation.Transition;
import javafx.animation.TranslateTransition;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;
import javafx.scene.Node;
import javafx.scene.paint.Color;
import javafx.scene.Scene;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.animation.Animation;
public class The_Space extends Application {
  
  
  // Anfang Attribute
  private static final int TILE_SIZE = 40;
  private static int WIDTH = 2550;
  private static int HEIGHT = 1080;   
  private Scene scene;
  int startX = 300; // Setzen Sie die gewünschte X-Startposition
  int startY = 100;  // Setzen Sie die gewünschte Y-Startposition
  // Globale Variablen für die Türposition
  private int doorX;
  private int doorY;                                                             
  // Globale Variable für die Tür-Auslösedistanz
  private final double DOOR_TRIGGER_DISTANCE = 40; // Setzen Sie den gewünschten Wert
  double doorHeight = TILE_SIZE;
  
  private boolean canShoot = true;  
  private boolean shooting = false;                                                                
  private Timeline bullets;
  private   String shootsound = "shot.mp3"; // Passen Sie den Pfad an
  private String wallhit = "wallhit.mp3";
  private String door = "Door.mp3";
  private ImageView doorImage;
  Image bulletImage = new Image("bullet.png");
  Image leftImage = new Image("Astronautleft.png");
  Image rightImage = new Image("Astronautright.png");
  Image weaponleftImage = new Image("waffeL.png");
  Image weaponrightImage = new Image("pistole.png"); 
  Image weaponUpImage = new Image("WaffeU.png");
  Image weaponDownImage = new Image("WaffeD.png");                                                                                                
  private ImageView player;                  
  private ImageView weapon;
  private ImageView bullet;
  private boolean moveUp, moveDown, moveLeft, moveRight;
  
  private double nextPlayerX;
  private double nextPlayerY;
  private double playerWidth;
  private double playerHeight;
  
  Pane root = new Pane();
  
  int[][] maze = {
  {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
  {1,3,2,2,2,2,4,1,1,1,1,1,1,3,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,4,1,1,1,1,1,1,1,1,1,1,1,1},
  {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},  
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},  
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,7,7,7,7,7,7,0,0,0,0,0,1},  
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,7,7,7,7,7,0,0,1},  
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,6,0,0,0,0,0,0,0,0,0,0,0,0,7,7,7,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,5,0,5,0,0,0,0,0,0,0,0,0,0,0,0,5},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1},
  {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1},
  // Add more rows as needed
  };
  
  private Pane mazePane = new Pane();
  private Pane bulletPane = new Pane(); // Definieren Sie eine Pane für die Kugeln
  private Pane floorPane = new Pane();
  
  
  private boolean canMove = true;   
  public boolean doorClosed = false; // Tür ist anfangs geschlossen
  boolean systemOutPrinted = false;
  boolean systemOutPrinted2 = false;
  boolean systemOutPrintdeadFloor = false;
  
  public Stage primaryStage;
  
  private GraphicsContext gc;
  
  private boolean machtDamage = false;
  
  private static int HP = 100;
  Text healthText = new Text();
  Text Eletter = new Text();
  public boolean geöffnet;
  private Camera camera;
  private HackminigameA hG;
  // BULLET_SPEED kann eine Konstante sein, die die Geschwindigkeit des Bullets definiert.
  private static final double BULLET_SPEED = 5.0;
  private double bulletVelocityX = 0;
  private double bulletVelocityY = 0;
  
  public void start(Stage primaryStage) {
    primaryStage.setTitle("The_Space");
    
    // Speichern Sie die primaryStage für den späteren Zugriff
    this.primaryStage = primaryStage;
    // Erstellen der Kamera mit den Grenzen des Spielfelds
    camera = new Camera(0, 0, 0, 0, 2550, 2000);
    
    Pane root = new Pane();
    
    healthText.setFont(Font.font("Arial", FontWeight.BOLD, 128)); // Schriftart und Größe festlegen
    healthText.setFill(Color.WHITE); // Textfarbe festlegen
    
    // Setzen Sie die anfänglichen Lebenspunkte
    
    healthText.setText( "" + HP); // Initialen Text festlegen
    
    // Positionieren Sie das Textfeld im HUD
    double textX = 1010; // X-Koordinate des Textfelds im HUD
    double textY = 100; // Y-Koordinate des Textfelds im HUD
    healthText.setLayoutX(textX);
    healthText.setLayoutY(textY);
    
    // Fügen Sie das Textfeld dem HUD hinzu
    root.getChildren().add(healthText);
    
    // Aktualisieren Sie das Textfeld, wenn sich die Lebenspunkte ändern
    // Annahme: Sie haben eine Methode namens "updateHealth(int health)", die aufgerufen wird, um die Lebenspunkte zu aktualisieren
    updateHealth(HP); // Rufen Sie diese Methode auf, um die Lebenspunkte anzuzeigen
    
    // Bild für den Ersteller
    Image hudImage = new Image("HUD.png"); // Passe den Pfad entsprechend an
    ImageView hudImageview = new ImageView(hudImage);
    hudImageview.setImage(hudImage);
    hudImageview.setFitWidth(1024); // Breite des Bildes
    hudImageview.setFitHeight(128); // Höhe des Bildes
    hudImageview.setLayoutX(450); // Neue x-Position
    hudImageview.setLayoutY(0); // Neue y-Position
    // Bild für den Ersteller
    Image faceImage = new Image("face.png"); // Passe den Pfad entsprechend an
    ImageView faceImageview = new ImageView(faceImage);
    faceImageview.setImage(faceImage);
    faceImageview.setFitWidth(512); // Breite des Bildes
    faceImageview.setFitHeight(300); // Höhe des Bildes
    faceImageview.setLayoutX(1110); // Neue x-Position
    faceImageview.setLayoutY(0); // Neue y-Position   
    
    
    
    
    
    root.setBackground(new Background(new BackgroundFill(Color.DARKBLUE, CornerRadii.EMPTY, Insets.EMPTY))); // Hintergrund für die root-Pane festlegen
    Scene scene = new Scene(root, WIDTH, HEIGHT); // Blauer Hintergrund
    // Anfang Komponenten
    // Ende Komponenten
    
    // Generiere zufällige Sterne und füge sie der root-Pane hinzu
    Random random = new Random();
    List<Circle> stars = new ArrayList<>(); // Liste zur Speicherung der Sterne
    for (int i = 0; i < 600; i++) {
      double x = random.nextDouble() * WIDTH;
      double y = random.nextDouble() * HEIGHT;
      Circle star = new Circle(x, y, 3, Color.WHITE); // Kleine weiße Kreise als Sterne
      stars.add(star); // Füge den Stern zur Liste hinzu
      root.getChildren().add(star);
    }
    
    drawMaze(root);
    
    scene.setOnMouseClicked(this::handleMouseClick);
    
    // Erzeuge ein ImageView für den Bullet
    bullet = new ImageView(bulletImage);
    
    // Setze die Größe des Bullets
    bullet.setFitWidth(TILE_SIZE );
    bullet.setFitHeight(TILE_SIZE );
    
    // Füge den Bullet der root-Pane hinzu
    root.getChildren().add(bullet);
    
    
    player = new ImageView(leftImage);
    player.setFitWidth(TILE_SIZE * 3);
    player.setFitHeight(TILE_SIZE * 3);
    player.setX((WIDTH - player.getFitWidth()) / 2);
    player.setY((HEIGHT - player.getFitHeight()) / 2);
    
    
    weapon = new ImageView(weaponleftImage);
    weapon.setFitWidth(TILE_SIZE * 1.5);
    weapon.setFitHeight(TILE_SIZE * 1.5);
    weapon.setX((WIDTH -  weapon.getFitWidth()) / 2.1);
    weapon.setY((HEIGHT - weapon.getFitHeight()) / 2.06);     
    
    // Setzen Sie den Mauszeiger auf transparent, um ihn zu verstecken
    // scene.setCursor(javafx.scene.Cursor.NONE);
    
    
    
    
    root.getChildren().addAll( player, weapon);
    // Fügen Sie das HUD-Bild am Ende hinzu
    root.getChildren().addAll(hudImageview , faceImageview); 
    
    
    // Bringen Sie das Textfeld in den Vordergrund
    healthText.toFront();
    
    scene.setOnMouseMoved(this::handleMouseMove);
    scene.setOnKeyPressed(event -> handleKeyPress(event.getCode()));
    scene.setOnKeyReleased(event -> handleKeyRelease(event.getCode()));
    
    primaryStage.setScene(scene);
    primaryStage.show();
    
    AnimationTimer timer = new AnimationTimer() {
      public void handle(long now) {
        
        // Bewege die Sterne nach links
        for (Circle star : stars) {
          star.setCenterX(star.getCenterX() - 1); // Ändern Sie hier die Geschwindigkeit der Sterne
          // Überprüfen, ob der Stern den linken Rand des Fensters erreicht hat, und setzen Sie ihn zurück auf den rechten Rand
          if (star.getCenterX() < 0) {
            star.setCenterX(WIDTH);
          }   
        }
        update(); // Aktualisieren Sie die Spiellogik
        
        
        
      }
      
      
    };
    timer.start();
  }
  

  
  // Anfang Methoden
  private void updateHealth(int healthPoints) {
    healthText.setText("" + healthPoints); // Aktualisieren Sie den Text des Textfelds mit den aktuellen Lebenspunkten
    
    if (isNextMoveValid(nextPlayerX, nextPlayerY, playerWidth, playerHeight, startX, startY) && systemOutPrintdeadFloor == true) {
      healthPoints -= 10; 
    } 
  } 
 
  
 
  public Stage getPrimaryStage() {
    return primaryStage;
  }
  
  
  
  private void drawMaze(Pane root) {
    Pane floorPane = new Pane();
    Pane bulletPane = new Pane(); // Definieren Sie eine Pane für die Kugeln
    Pane doorPane = new Pane();
    Pane wallPane = new Pane();
    
    
    root.getChildren().addAll(bulletPane,floorPane,wallPane, doorPane  ); 
    
    int startX = 300; // Setzen Sie die gewünschte X-Startposition
    int startY = 100;  // Setzen Sie die gewünschte Y-Startposition
    
    //    // Fügen Sie die Tür hinzu, nachdem alle Wandbilder hinzugefügt wurden
    //    for (int row = 0; row < maze.length; row++) {
    //      for (int col = 0; col < maze[row].length; col++) {
    //        if (maze[row][col] == 5) { // Annahme, dass der Wert 5 für Türen steht
    //          // Tür
    //          ImageView doorImage = new ImageView(new Image("door.png"));
    //          doorImage.setFitWidth(TILE_SIZE);
    //          doorImage.setFitHeight(TILE_SIZE * 2); // Vergrößern Sie die Höhe der Tür, um sie länger zu machen
    //          doorImage.setX(col * TILE_SIZE + startX);
    //          doorImage.setY(row * TILE_SIZE - startY + TILE_SIZE * 5); // Verschieben Sie die Tür nach oben, um sie länger zu machen
    //          doorPane.getChildren().add(doorImage);
    //        }
    //      }
    //    }
    
    for (int row = 0; row < maze.length; row++) {
      for (int col = 0; col < maze[row].length; col++) {
        if (maze[row][col] == 1) {
          // Wand
          ImageView wallImage = new ImageView(new Image("wall.png"));
          wallImage.setFitWidth(TILE_SIZE);
          wallImage.setFitHeight(TILE_SIZE);
          wallImage.setX(col * TILE_SIZE + startX);
          wallImage.setY(row * TILE_SIZE + startY);
          wallPane.getChildren().add(wallImage);
        } else if (maze[row][col] == 2) {
          // Mittleres Fenster
          ImageView windowImage = new ImageView(new Image("windowMiddle.png"));
          windowImage.setFitWidth(TILE_SIZE);
          windowImage.setFitHeight(TILE_SIZE);
          windowImage.setX(col * TILE_SIZE + startX);
          windowImage.setY(row * TILE_SIZE + startY);
          wallPane.getChildren().add(windowImage);  
        } else if (maze[row][col] == 3) {
          // Linkes Fenster
          ImageView windowLImage = new ImageView(new Image("windowLeft.png"));
          windowLImage.setFitWidth(TILE_SIZE);
          windowLImage.setFitHeight(TILE_SIZE);
          windowLImage.setX(col * TILE_SIZE + startX);
          windowLImage.setY(row * TILE_SIZE + startY);
          wallPane.getChildren().add(windowLImage);    
        } else if (maze[row][col] == 4) {
          // Rechtes Fenster
          ImageView windowRImage = new ImageView(new Image("windowRight.png"));
          windowRImage.setFitWidth(TILE_SIZE);
          windowRImage.setFitHeight(TILE_SIZE);
          windowRImage.setX(col * TILE_SIZE + startX);
          windowRImage.setY(row * TILE_SIZE + startY);
          wallPane.getChildren().add(windowRImage);       
        } else {
          // Boden
          ImageView floorImage = new ImageView(new Image("floor.png"));
          floorImage.setFitWidth(TILE_SIZE);
          floorImage.setFitHeight(TILE_SIZE);
          floorImage.setX(col * TILE_SIZE + startX);
          floorImage.setY(row * TILE_SIZE + startY);
          floorPane.getChildren().add(floorImage);
        } if (maze[row][col] == 7) {
          ImageView poisonFloorImage = new ImageView(new Image("PoisonFloor.gif"));
          poisonFloorImage.setFitWidth(TILE_SIZE);
          poisonFloorImage.setFitHeight(TILE_SIZE);
          poisonFloorImage.setX(col * TILE_SIZE + startX);
          poisonFloorImage.setY(row * TILE_SIZE + startY);
          floorPane.getChildren().add(poisonFloorImage);  
          machtDamage = true;
        } // end of if
        
        if (maze[row][col] == 5) { // Annahme, dass der Wert 5 für Türen steht
          // Tür
          ImageView doorImage = new ImageView(new Image("door.png"));
          doorImage.setFitWidth(TILE_SIZE);
          doorImage.setFitHeight(TILE_SIZE *2 ); // Vergrößern Sie die Höhe der Tür, um sie länger zu machen
          doorImage.setX(col * TILE_SIZE + startX);
          doorImage.setY(row * TILE_SIZE - startY + TILE_SIZE * 4);
          wallPane.getChildren().add(doorImage);
          
        }  if (maze[row][col] == 6) { // Annahme, dass der Wert 5 für Türen steht
          // Tür
          ImageView doorImage = new ImageView(new Image("door.png"));
          doorImage.setFitWidth(TILE_SIZE);
          doorImage.setFitHeight(TILE_SIZE *2 ); // Vergrößern Sie die Höhe der Tür, um sie länger zu machen
          doorImage.setX(col * TILE_SIZE + startX);
          doorImage.setY(row * TILE_SIZE - startY + TILE_SIZE * 4);
          wallPane.getChildren().add(doorImage);
          
        } 
      }         
    }
    
  }  
  
  
         
  private void update() {
    // Hier können Sie die Spiellogik aktualisieren, z.B. Benutzereingaben verarbeiten
    int Speed = 2;
    
    // Bewegung des Spielers und der Waffe basierend auf Benutzereingaben und Kollisionsstatus
    if (moveLeft) {   
      if (canMove && player.getX() > 0 && isNextMoveValid(player.getX() - Speed, player.getY(), player.getFitWidth(), player.getFitHeight(), startX, startY)) {
        player.setX(player.getX() - Speed);
        weapon.setX(weapon.getX() - Speed);
      }
    }
    
    if (moveRight) {          
      if (canMove && player.getX() < WIDTH - player.getFitWidth() && isNextMoveValid(player.getX() + Speed, player.getY(), player.getFitWidth(), player.getFitHeight(), startX, startY)) {
        player.setX(player.getX() + Speed);
        weapon.setX(weapon.getX() + Speed);
      }
    }
    
    if (moveUp) {           
      if (canMove && player.getY() > 0 && isNextMoveValid(player.getX(), player.getY() - Speed, player.getFitWidth(), player.getFitHeight(), startX, startY)) {
        player.setY(player.getY() - Speed);
        weapon.setY(weapon.getY() - Speed);
      }
    }
    
    if (moveDown) {             
      if (canMove && player.getY() < HEIGHT - player.getFitHeight() && isNextMoveValid(player.getX(), player.getY() + Speed, player.getFitWidth(), player.getFitHeight(), startX, startY)) {
        player.setY(player.getY() + Speed);
        weapon.setY(weapon.getY() + Speed);
      }
    }     
    
    
    
  }
  
  private boolean isNextMoveValid(double nextPlayerX, double nextPlayerY, double playerWidth, double playerHeight, int startX, int startY) {
    // Überprüfe, ob der nächste Zug innerhalb der Spielfeldgrenzen liegt und ob er auf eine Wand trifft
    double halfPlayerWidth = playerWidth / 1.4; // Halbe Breite des Spielers
    double halfPlayerWidth2 = playerWidth / 5; // Halbe Breite des Spielers
    double halfPlayerHeight = playerHeight / 1.4; // Halbe Breite des Spielers
    for (int row = 0; row < maze.length; row++) {
      for (int col = 0; col < maze[row].length; col++) {
        if (maze[row][col] == 1) {
          double wallX = col * TILE_SIZE + startX;
          double wallY = row * TILE_SIZE + startY;
          double wallWidth = TILE_SIZE;
          double wallHeight = TILE_SIZE;
          
          // Überprüfe, ob die linke Seite des Spielers kollidiert
          if (nextPlayerX + halfPlayerWidth > wallX &&
          nextPlayerX + halfPlayerWidth2 < wallX + wallWidth &&
          nextPlayerY + halfPlayerHeight < wallY + wallHeight &&
          nextPlayerY + playerHeight > wallY) {
            
            return false; // Kollision erkannt, Zug ist ungültig
          }
        }
        
        // Überprüfen auf Kollision mit der Tür, falls vorhanden
        // Überprüfen auf Kollision mit der Tür, falls vorhanden
        if (maze[row][col] == 5 && !doorClosed) {
          // Türposition und Abmessungen festlegen
          double doorX = col * TILE_SIZE + startX;
          double doorY = row * TILE_SIZE + startY;
          double doorWidth = TILE_SIZE;
          doorHeight = TILE_SIZE;
          
          // Überprüfen, ob der Spieler sich direkt vor der Tür befindet und die Tür betritt
          if (nextPlayerX + halfPlayerWidth > doorX &&
          nextPlayerX + halfPlayerWidth2 < doorX + doorWidth &&
          nextPlayerY + halfPlayerHeight < doorY + doorHeight &&
          nextPlayerY + playerHeight > doorY) {
            System.out.println("Spieler ist direkt vor der Tür. Taste E zum Öffnen der Tür drücken."); 
            systemOutPrinted = true;
            return false; // Spieler steht vor der Tür, Zug ist ungültig
          }
          
        }       
        if (maze[row][col] == 6 && !doorClosed) {
          // Türposition und Abmessungen festlegen
          double doorX = col * TILE_SIZE + startX;
          double doorY = row * TILE_SIZE + startY;
          double doorWidth = TILE_SIZE;
          doorHeight = TILE_SIZE;
          
          // Überprüfen, ob der Spieler sich direkt vor der Tür befindet und die Tür betritt
          if (nextPlayerX + halfPlayerWidth > doorX &&
          nextPlayerX + halfPlayerWidth2 < doorX + doorWidth &&
          nextPlayerY + halfPlayerHeight < doorY + doorHeight &&
          nextPlayerY + playerHeight > doorY) {
            System.out.println("Spieler ist direkt vor der Tür. Taste E zum Öffnen der Tür drücken."); 
            systemOutPrinted2 = true;
            return false; // Spieler steht vor der Tür, Zug ist ungültig
          }
          
        } 
        
        if (maze[row][col] == 7) {
          double wallX = col * TILE_SIZE + startX;
          double wallY = row * TILE_SIZE + startY;
          double wallWidth = TILE_SIZE;
          double wallHeight = TILE_SIZE;
          
          // Überprüfe, ob die linke Seite des Spielers kollidiert
          if (nextPlayerX + halfPlayerWidth > wallX &&
          nextPlayerX + halfPlayerWidth2 < wallX + wallWidth &&
          nextPlayerY + halfPlayerHeight < wallY + wallHeight &&
          nextPlayerY + playerHeight > wallY) {
            System.out.println("Berührst Tödlichen Boden");
            
            // Überprüfe, ob der Spieler den tödlichen Boden berührt hat
            if (!systemOutPrintdeadFloor) {
              // Aktualisiere die Lebenspunkte
              updateHealth(HP - 10);
              // Setze den Zustand, dass der Spieler den tödlichen Boden berührt hat
              systemOutPrintdeadFloor = true;
            }
            
            
            
            return true;
          } 
        }      
      }
      
    }   
    
    return true; // Keine Kollision erkannt, Zug ist gültig
    
  }
      
  private void updateWeaponPosition() {
    if (weapon != null) {
      if (player.getImage().getUrl().contains("Astronautleft")) {
        // Spieler schaut nach links
        weapon.setX(player.getX() - TILE_SIZE * 0.7);
        weapon.setY(player.getY() + player.getFitHeight() / 8);
      } else if (player.getImage().getUrl().contains("Astronautright")) {
        // Spieler schaut nach rechts
        weapon.setX(player.getX() + player.getFitWidth() - TILE_SIZE * 1.1);
        weapon.setY(player.getY() + player.getFitHeight() / 8);
      } else if (player.getImage().getUrl().contains("AstronautUp")) {
        // Spieler schaut nach oben
        weapon.setX(player.getX() + player.getFitWidth() / 3);
        weapon.setY(player.getY() - TILE_SIZE * 0.7);
      } else if (player.getImage().getUrl().contains("AstronautDown")) {
        // Spieler schaut nach unten
        weapon.setX(player.getX() + player.getFitWidth() / 3.5);
        weapon.setY(player.getY() + player.getFitHeight() - TILE_SIZE * 1.8);
      }
    }
  }
  
  
    
  
    
  
  private void handleKeyPress(KeyCode code) {
    // Hier können Sie auf Tasten drücken reagieren
    switch (code) {
      case W:
        moveUp = true;  
        break;
      case S:
        moveDown = true;
        break;
      case A:
        moveLeft = true;
        break;
      case D:
        moveRight = true;
        break;
      case E:
        // Überprüfen Sie, ob der Spieler sich in der Nähe der Tür befindet
        System.out.println("E");
        
        
        
        //    // Annahme: Hier wird der Spieler durch die Tür bewegt
        if (isNextMoveValid(nextPlayerX, nextPlayerY, playerWidth, playerHeight, startX, startY) && systemOutPrinted == true) {
          systemOutPrinted = false;
          
          // Tür öffnen
          doorClosed = true;
          
          
          
          // Erstellen Sie ein File-Objekt mit dem relativen Pfad
          File file = new File(door);
          // Konvertieren Sie das File-Objekt in eine URI
          String uriString = file.toURI().toString();
          // Erstellen Sie die Media mit der URI
          Media sound = new Media(uriString);
          MediaPlayer mediaPlayer = new MediaPlayer(sound);
          // Setzen Sie die Lautstärke auf 0.5 (50% Lautstärke)
          mediaPlayer.setVolume(1);
          // Event Listener, um den MediaPlayer nach dem Abspielen freizugeben
          mediaPlayer.setOnEndOfMedia(() -> mediaPlayer.dispose());
          // Abspielen des Sounds
          mediaPlayer.play();
          
          // Timeline für Animation erstellen
          Timeline timeline = new Timeline(
          new KeyFrame(Duration.millis(10), event -> doormoove())
          );
          timeline.setCycleCount(63);
          timeline.setOnFinished(event -> {
            System.out.println("Timer um");
            doorClosed = false;
            timeline.stop(); // Timer stoppen, wenn abgelaufen
          });
          
          timeline.play();
          System.out.println("Timer läuft");
          
        }
        
        if (isNextMoveValid(nextPlayerX, nextPlayerY, playerWidth, playerHeight, startX, startY) && systemOutPrinted2 == true) {
          systemOutPrinted2 = false;
          geöffnet = true;
          // Erstellen einer Instanz von The_Space
          hG = new HackminigameA();
          
          // Erstellen einer neuen Stage für The_Space
          Stage ministage = new Stage();
          
          // Starten von The_Space und Übergabe der Stage
          hG.start(ministage);
          
          
          if (geöffnet == true) { 
            
            doorClosed = true;
            geöffnet = false;
            
            
            
            // Timeline für Animation erstellen
            Timeline timeline = new Timeline(
            new KeyFrame(Duration.millis(10), event -> doormoove())
            );
            timeline.setCycleCount(500);
            timeline.setOnFinished(event -> {
              System.out.println("Timer um");
              doorClosed = false;
              timeline.stop(); // Timer stoppen, wenn abgelaufen
            });
            
            timeline.play();
            System.out.println("Timer läuft");
            
            
          } // end of if end of if
        }
        
        break;
      
      
      default:
        
        break;
      
      
      
    }
  }
       
  private void doormoove() {
    // Nur für die timeline
  }
  
  
       
  private void handleKeyRelease(KeyCode code) {
    // Hier können Sie auf Tasten loslassen reagieren
    switch (code) {
      case W:
        moveUp = false;
        break;
      case S:
        moveDown = false;
        break;
      case A:
        moveLeft = false;
        break;
      case D:
        moveRight = false;
        break;
      
    }
  }
  double bulletX;
  double bulletY;
            
  private void handleMouseMove(MouseEvent event) {
    mouseX = event.getX();
    mouseY = event.getY();
    
    double playerCenterX = player.getX() + player.getFitWidth() / 2;
    double playerCenterY = player.getY() + player.getFitHeight() / 2;
    // Setze die Position des Bullets basierend auf der Waffe des Spielers
    bulletX = weapon.getX();
    bulletY = weapon.getY();
    
    double dx = mouseX - playerCenterX;
    double dy = mouseY - playerCenterY;
    
    // Horizontal movement
    if (Math.abs(dx) > Math.abs(dy)) {
      if (dx < 0) {
        
        player.setImage(new Image("Astronautleft.png"));
        weapon.setImage(new Image("waffeL.png"));
        
      } else {
        
        player.setImage(new Image("Astronautright.png"));
        weapon.setImage(new Image("pistole.png"));
      }
    } else { // Vertical movement
      if (dy < 0) {
        
        player.setImage(new Image("AstronautUp.png"));
        weapon.setImage(new Image("WaffeU.png"));
        
      } else {
        
        player.setImage(new Image("AstronautDown.png"));
        weapon.setImage(new Image("WaffeD.png"));
      } 
      
      
    } 
    
    
    
    
    updateWeaponPosition();
  } 
  double mouseX, mouseY;
  // Ende Attribute       
   private double bulletDirectionX;
  private double bulletDirectionY;
  //bei copy and paste Windows + V        
          
   private void handleMouseClick(MouseEvent event) {
    if (event.getButton() == MouseButton.PRIMARY) {
      // Schießen auslösen
      shoot();
    }
  }

  private void shoot() {
    System.out.println("Schuss");
    
    // Mache den Bullet sichtbar
    bullet.setVisible(true);
    
    // Setze die Position des Bullets basierend auf der Blickrichtung des Spielers
    setBulletStartPosition();
    
    // Starte die Bewegung des Bullets
    moveBullet();
    
    playShootSound(shootsound);
  }

  private void setBulletStartPosition() {
    bulletX = weapon.getX();
    bulletY = weapon.getY();
    
    if (player.getImage().getUrl().contains("Astronautleft")) {
      // Spieler schaut nach links
      bulletX = weapon.getX() - TILE_SIZE * 0.2;
      bulletY = weapon.getY() + weapon.getFitHeight() / 6;
      bulletDirectionX = -1; // Nach links
      bulletDirectionY = 0;
      
    } else if (player.getImage().getUrl().contains("Astronautright")) {
      // Spieler schaut nach rechts
      bulletX = weapon.getX() + weapon.getFitWidth() - TILE_SIZE / 1.2;
      bulletY = weapon.getY() + weapon.getFitHeight() / 6;
      bulletDirectionX = 1; // Nach rechts
      bulletDirectionY = 0;
      
    } else if (player.getImage().getUrl().contains("AstronautUp")) {
      // Spieler schaut nach oben
      bulletX = weapon.getX() + weapon.getFitWidth() - 67;
      bulletY = weapon.getY() - TILE_SIZE + 100;
      bulletDirectionX = 0;
      bulletDirectionY = -1; // Nach oben
      
    } else if (player.getImage().getUrl().contains("AstronautDown")) {
      // Spieler schaut nach unten
      bulletX = weapon.getX() + weapon.getFitWidth() - 50;
      bulletY = weapon.getY() + weapon.getFitHeight() - TILE_SIZE / 1.1;
      bulletDirectionX = 0;
      bulletDirectionY = 1; // Nach unten
    }
    
    // Setze die Position des Bullets
    bullet.setTranslateX(bulletX);
    bullet.setTranslateY(bulletY);
  }

  private void moveBullet() {
    // Überprüfen, ob bereits eine Bullet-Bewegung läuft
    if (bullets != null && bullets.getStatus() == Animation.Status.RUNNING) {
      // Wenn eine Bewegung bereits läuft, stoppe sie nicht, sondern lasse sie weiterlaufen
      return;
    }
    
    // Erstelle eine neue Timeline für die Bewegung des Bullets
    bullets = new Timeline(new KeyFrame(Duration.millis(10), event -> {
      // Bewegungslogik für den Bullet hier einfügen
      double speed = 1.5; // Geschwindigkeit des Bullets
      
      // Bewegung des Bullets basierend auf der festgelegten Richtung
      bullet.setTranslateX(bullet.getTranslateX() + bulletDirectionX * speed);
      bullet.setTranslateY(bullet.getTranslateY() + bulletDirectionY * speed);
      
      // Überprüfen, ob der Bullet außerhalb des Bildschirms ist und ihn gegebenenfalls unsichtbar machen
      if (bullet.getTranslateX() < 0 || bullet.getTranslateX() > WIDTH || bullet.getTranslateY() < 0 || bullet.getTranslateY() > HEIGHT) {
        bullet.setVisible(false); // Mache den Bullet unsichtbar, wenn er den Bildschirm verlässt
        stopBulletMovement(); // Stoppe die Bewegung des Bullets
      }
    }));
    
    // Die Bewegung soll unendlich oft wiederholt werden, bis der Bullet den Bildschirm verlässt
    bullets.setCycleCount(Timeline.INDEFINITE);
    
    // Starte die Bewegung des Bullets
    bullets.play();
  }

  private void stopBulletMovement() {
    // Überprüfe, ob eine Bewegung läuft, und stoppe sie
    if (bullets != null) {                                                                                
      bullets.stop();
    }
  }

  private void playShootSound(String soundFile) {
    // Erstellen Sie ein File-Objekt mit dem relativen Pfad
    File file = new File(soundFile);
    
    // Konvertieren Sie das File-Objekt in eine URI
    String uriString = file.toURI().toString();
    
    // Erstellen Sie die Media mit der URI
    Media sound = new Media(uriString);
    MediaPlayer mediaPlayer = new MediaPlayer(sound);
    
    // Setzen Sie die Lautstärke auf 0.5 (50% Lautstärke)
    mediaPlayer.setVolume(0.5);
    
    // Event Listener, um den MediaPlayer nach dem Abspielen freizugeben
    mediaPlayer.setOnEndOfMedia(() -> mediaPlayer.dispose());
    
    // Abspielen des Sounds
    mediaPlayer.play();
  }
  
          
 

  // Ende Methoden
}