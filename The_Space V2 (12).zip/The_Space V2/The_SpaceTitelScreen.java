import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.stage.Stage;
import javafx.scene.paint.Color;
import java.util.Random;
import javafx.scene.image.Image;
import javafx.animation.Timeline;
import javafx.animation.KeyFrame;
import javafx.util.Duration;
import javafx.scene.image.ImageView;
import javafx.scene.control.Button;
import javafx.application.Platform;
import javafx.scene.control.TextField;

public class The_SpaceTitelScreen extends Application {
  // Anfang Attribute
  public int breite = 2550;
  public int hoehe  = 1440;
  private double spaceshipX = breite / 2;
  private double spaceshipY = hoehe / 2;
  private double titleX = breite / 2;
  private double titleY = hoehe / 2;
  private double DeadAstronautX = breite / 2;
  private double DeadAstronautY = hoehe / 2;
  
  public Stage primaryStage;
  
  
  // Ende Attribute
  
  public static void main(String[] args) {
    launch(args);
  }
  
  @Override
  public void start(Stage primaryStage) {
    this.primaryStage = primaryStage;
    primaryStage.setTitle("The_Space");
    
    Group root = new Group();
    Canvas canvas = new Canvas(breite, hoehe); // Breite x Höhe des Canvas
    root.getChildren().add(canvas);
    primaryStage.setFullScreen(true);
    primaryStage.setFullScreenExitHint("");
    
    GraphicsContext gc = canvas.getGraphicsContext2D();
    
    
    drawField(gc);         
    
    // Bild für den Ersteller
    Image JPKGames = new Image("JPKGames.png"); // Passe den Pfad entsprechend an
    ImageView JPKGamesImageview = new ImageView(JPKGames);
    JPKGamesImageview.setImage(JPKGames);
    JPKGamesImageview.setFitWidth(300); // Breite des Bildes
    JPKGamesImageview.setFitHeight(300); // Höhe des Bildes
    JPKGamesImageview.setLayoutX(100); // Neue x-Position
    JPKGamesImageview.setLayoutY(1150); // Neue y-Position                                   
    root.getChildren().add(JPKGamesImageview);
    // Hier wird das Raumschiff in der Mitte des Feldes platziert
    Image spaceshipImage = new Image(getClass().getResourceAsStream("Raumschiff.gif"));
    
    ImageView spaceshipImageView = new ImageView(spaceshipImage);
    double sneueBreite = 1500 ; // Hier die gewünschte Breite einsetzen
    double sneueHoehe = 1000 ;  // Hier die gewünschte Höhe einsetzen
    
    spaceshipImageView.setFitWidth(sneueBreite);
    spaceshipImageView.setFitHeight(sneueHoehe);
    
    spaceshipX = (breite - spaceshipImage.getWidth()) / 2;
    spaceshipY = (hoehe - spaceshipImage.getHeight()) / 2;
    spaceshipImageView.setX(spaceshipX);
    spaceshipImageView.setY(spaceshipY);
    root.getChildren().add(spaceshipImageView);                            
    
    Image DeadAstronaut = new Image(getClass().getResourceAsStream("DeadAstronautAnimation.gif"));
    
    ImageView DeadAstronautImageView = new ImageView(DeadAstronaut);
    // Setze die gewünschte Breite und Höhe für das Bild
    double neueBreite = 1500 ; // Hier die gewünschte Breite einsetzen
    double neueHoehe = 1000 ;  // Hier die gewünschte Höhe einsetzen
    
    DeadAstronautImageView.setFitWidth(neueBreite);
    DeadAstronautImageView.setFitHeight(neueHoehe);
    
    DeadAstronautX = (breite - DeadAstronaut.getWidth()) / 1.5;
    DeadAstronautY = (hoehe - DeadAstronaut.getHeight()) / 2;
    DeadAstronautImageView.setX(DeadAstronautX);
    DeadAstronautImageView.setY(DeadAstronautY);
    root.getChildren().add(DeadAstronautImageView);                               
    
    // Timeline für Animation erstellen
    Timeline timeline = new Timeline(
    new KeyFrame(Duration.millis(16), event -> moveSpaceship())
    );
    timeline.setCycleCount(Timeline.INDEFINITE);
    timeline.play();
    
    Image titleImage = new Image("Titel.gif");
    ImageView titleImageview = new ImageView(titleImage);
    
    titleX = (breite - titleImage.getWidth()) / 2;
    titleY = (hoehe - titleImage.getHeight()) / 20;
    titleImageview.setX(titleX);
    titleImageview.setY(titleY);
    root.getChildren().add(titleImageview); 
    
    // Button zum Starten des Spiels
    Button playButton = new Button("Spielen");
    playButton.setLayoutX(1180);
    playButton.setLayoutY(1000);
    playButton.setPrefWidth(200); // Breite auf 200 Pixel erhöht
    playButton.setPrefHeight(60); // Höhe auf 40 Pixel erhöht
    
    // Bild für den Button
    Image playImage = new Image("play.png"); // Passe den Pfad entsprechend an
    ImageView playImageView = new ImageView(playImage);
    playImageView.setFitWidth(400); // Breite des Bildes
    playImageView.setFitHeight(150); // Höhe des Bildes
    playButton.setGraphic(playImageView);
    
    
    
    // Methode für die Aktion, die beim Klicken auf den Button ausgeführt wird
    playButton.setOnAction(event -> startGame());
    
    root.getChildren().add(playButton);  
    
    
    // Button zum Beenden des Spiels
    Button byeButton = new Button("Beenden");
    byeButton.setLayoutX(1180);
    byeButton.setLayoutY(1150);
    byeButton.setPrefWidth(200); // Breite auf .. Pixel erhöht
    byeButton.setPrefHeight(100); // Höhe auf .. Pixel erhöht
    
    // Bild für den Button
    Image byeImage = new Image("end.png"); // Passe den Pfad entsprechend an
    ImageView byeImageview = new ImageView(byeImage);
    byeImageview.setFitWidth(400); // Breite des Bildes
    byeImageview.setFitHeight(150); // Höhe des Bildes
    byeButton.setGraphic(byeImageview);
    
    // Methode für die Aktion, die beim Klicken auf den Button ausgeführt wird
    byeButton.setOnAction(event -> endGame());
    
    root.getChildren().add(byeButton); 
    
    
    Scene scene = new Scene(root);
    primaryStage.setScene(scene);
    primaryStage.show();       
  }
  
  private void drawField(GraphicsContext gc) {
    // Hier kannst du dein Feld zeichnen
    // Beispiel: Ein grünes Rechteck als Spielfeld
    gc.setFill(javafx.scene.paint.Color.DARKBLUE);                         
    gc.fillRect(0, 0, breite, hoehe);
    
    // Draw random points in the field          
    gc.setFill(Color.WHITE);               
    Random random = new Random();
    for (int i = 0; i < 100; i++) {
      double x = random.nextDouble() * breite;
      double y = random.nextDouble() * hoehe;
      gc.fillRect(x, y, 10, 10);
    }
  }
  
  private void moveSpaceship() {  //NICHT GEBRAUCHT
    // NUR FÜR DIE TIMELINE DA!    
  }
  
  
  
  
  public void startGame() {
    // Erstellen einer Instanz von The_Space
    The_Space space = new The_Space();
    
    // Erstellen einer neuen Stage für The_Space
    Stage spaceStage = new Stage();
    
    // Starten von The_Space und Übergabe der Stage
    space.start(spaceStage);
    this.primaryStage.close();
    
  }
  
  private void endGame() {
    Platform.exit();
  }
  
  
  
} // end of class The_Space
